// Admin Now Playing page ("/admin/now-playing")
// Placeholder: For managing or displaying what's currently playing during events.

export default function Page() {
  return <h1 className="text-2xl font-bold">Now Playing (Admin) — placeholder</h1>
}
