// Admin Add Customer Vinyl page ("/admin/add-customer-vinyl")
// Placeholder: This page will let admins add customer-owned vinyl to the collection (coming soon).

export default function Page() {
  return <h1 className="text-2xl font-bold">Add Customer Vinyl (placeholder)</h1>;
}
